<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ShoeModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }

    public function daftarSepatu()
    {
        $sepatuModel = new ShoeModel();

        $data['shoes'] = $sepatuModel->findAll();

        return view('admin/daftar-sepatu', $data);
    }

    public function daftarSepatuTambah()
    {
        return view('admin/daftar-sepatu-tambah');
    }

    public function createSepatu()
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('cover');

        if ($file && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path;
        }

        $sepatuModel = new ShoeModel();

        if ($sepatuModel->insert($data, false)) {
            return redirect()->to('admin/daftar-sepatu')->with('berhasil', 'Data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-sepatu')->with('gagal', 'Data gagal disimpan!');
        }
    }

    public function daftarSepatuEdit($id)
    {
        $sepatuModel = new ShoeModel();
        $shoes = $sepatuModel->find($id);
    
        if (!$shoes) {
            return redirect()->to('admin/daftar-sepatu')->with('gagal', 'Data sepatu tidak ditemukan!');
        }
    
        return view('admin/daftar-sepatu-edit', ['shoes' => $shoes]);
    }
    
    public function changeSepatu($id)
    {
        $sepatuModel = new ShoeModel(); 
        $existingShoe = $sepatuModel->find($id); 
    
        if (!$existingShoe) {
            return redirect()->to('admin/daftar-sepatu')->with('gagal', 'Data sepatu tidak ditemukan!');
        }
    
        $data = $this->request->getPost(); 
        $file = $this->request->getFile('cover');
    
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path; 
        } else {
            $data['cover'] = $existingShoe['cover'];
        }
    
        if ($sepatuModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sepatu')->with('berhasil', 'Data berhasil diperbarui!');
        } else {
            return redirect()->to('admin/daftar-sepatu')->with('gagal', 'Data gagal diperbarui!');
        }
    }
    public function hapusSepatu($id)
    {
        $shoeModel = new \App\Models\ShoeModel();
    
        $sepatu = $shoeModel->find($id);
    
        if ($sepatu) {
            $shoeModel->delete($id);
    

            return redirect()->to('/admin/daftar-sepatu')->with('success', 'Sepatu berhasil dihapus.');
        }

        return redirect()->to('/admin/daftar-sepatu')->with('error', 'Sepatu tidak ditemukan.');
    }
    
    

    public function transaksi()
    {
        return view('admin/transaksi');
    }
 
    public function transaksiUbahStatus()
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus()
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan()
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus()
    {
        return view('admin/pelanggan-hapus');
    }
}
