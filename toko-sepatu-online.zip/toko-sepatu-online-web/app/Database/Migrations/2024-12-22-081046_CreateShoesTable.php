<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSepatuTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
            ],
            'nama' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'merk' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'ukuran' => [
                'type' => 'INT',
                'constraint' => 3,
            ],
            'warna' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'cover'=> [
                'type' =>'VARCHAR',
                'constraint'=> 250,
            ],
            'stok' => [
                'type' => 'INT',
                'constraint' => 11,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 16,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('shoes');
    }

    public function down()
    {
        $this->forge->dropTable('shoes');
    }
}
