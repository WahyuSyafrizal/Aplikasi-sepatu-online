<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Sepatu Online Yuhu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <style>
        .hero-section {
            background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            color: white;
            border-radius: 1rem;
            margin: 2rem 0;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .search-form {
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 1rem;
            backdrop-filter: blur(10px);
        }
        
        .card {
            border: none;
            transition: transform 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .price {
            color: #6366f1;
            font-weight: bold;
            font-size: 1.25rem;
        }
        
        .btn-cart {
            position: relative;
            transition: all 0.3s ease;
            text-decoration: none;
            color: white;
        }
        
        .btn-cart:hover {
            transform: scale(1.05);
            color: white;
            opacity: 0.9;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
        }
        
        footer {
            background: #1f2937;
            color: white;
            padding: 2rem 0;
            margin-top: 4rem;
        }

        .navbar-buttons {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .btn-logout {
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            transform: scale(1.05);
            opacity: 0.9;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light sticky-top mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="fas fa-shoe-prints me-2"></i>
                Yuhu Shoes
            </a>
            
            <div class="navbar-buttons">
                <a href="<?= base_url() ?>chart" class="btn btn-primary btn-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="badge bg-danger cart-badge">3</span>
                </a>
                <div class="col">
                
                <a href="<?= base_url('logout')?>" class="btn btn-danger btn-logout">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="hero-section">
            <div class="row g-0">
                <div class="col-md-6 p-5">
                    <h1 class="display-4 fw-bold mb-4">Temukan Gaya Anda di Yuhu Shoes</h1>
                    <p class="lead mb-4">Koleksi sepatu terbaik untuk gaya hidup modern Anda</p>
                    <a href="#products" class="btn btn-light btn-lg">
                        Lihat Koleksi
                        <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                </div>
                <div class="col-md-6 p-5">
                    <div class="search-form">
                        <h2 class="h4 mb-4">Cari Sepatu Impian Anda</h2>
                        <form>
                            <div class="mb-3">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" placeholder="Merek Sepatu" />
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-palette"></i></span>
                                    <input type="text" class="form-control" placeholder="Warna" />
                                </div>
                            </div>
                            <button class="btn btn-light w-100">Cari Sekarang</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <section id="products" class="my-5">
            <h2 class="display-6 fw-bold mb-4">Best Sellers
                <span class="badge bg-danger ms-2">Hot</span>
            </h2>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card h-100">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-danger">New</span>
                        </div>
                        <img src="images/sepatu.jpg" class="card-img-top" alt="Sepatu 1" />
                        <div class="card-body">
                            <h5 class="card-title">Nike Air Max</h5>
                            <p class="price mb-3">Rp 850,000</p>
                            <a href="<?= base_url() ?>chart" class="btn btn-primary w-100">
                                <i class="fas fa-shopping-chart me-2"></i>
                                Add to Cart
                                
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card h-100">
                        <img src="images/sepatu1.jpg" class="card-img-top" alt="Sepatu 2" />
                        <div class="card-body">
                            <h5 class="card-title">Adidas Ultraboost</h5>
                            <p class="price mb-3">Rp 1,000,000</p>
                            <a href="<?= base_url() ?>chart" class="btn btn-primary w-100">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Add to Cart
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100">
                        <img src="images/sepatu2.jpg" class="card-img-top" alt="Sepatu 3" />
                        <div class="card-body">
                            <h5 class="card-title">Puma RS-X</h5>
                            <p class="price mb-3">Rp 1,850,000</p>
                            <a href="<?= base_url() ?>chart" class="btn btn-primary w-100">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Add to Cart
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-warning">Sale</span>
                        </div>
                        <img src="images/sepatu4.jpg" class="card-img-top" alt="Sepatu 4" />
                        <div class="card-body">
                            <h5 class="card-title">Reebok Classic</h5>
                            <p class="price mb-3">Rp 1,250,000</p>
                            <a href="<?= base_url() ?>chart" class="btn btn-primary w-100">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Add to Cart
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5 class="mb-3">Yuhu Shoes</h5>
                    <p class="text-muted">Toko sepatu online terpercaya dengan koleksi terlengkap</p>
                </div>
                <div class="col-md-4">
                    <h5 class="mb-3">Hubungi Kami</h5>
                    <a href="#" class="text-white"><i class="fab fa-WhatsApp fa-lg">082279190337</i></a>
                    <p class="text-muted">
                        <i class="fas fa-envelope me-2"></i> info@yuhushoes.com<br>
                        <i class="fas fa-phone me-2"></i> (021) 123-4567
                    </p>
                </div>
                <div class="col-md-4">
                    <h5 class="mb-3">Ikuti Kami</h5>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white"><i class="fab fa-facebook fa-lg">Yuhusepatu</i></a>
                        <a href="#" class="text-white"><i class="fab fa-instagram fa-lg">Toko_yuhu</i></a>
                        <a href="#" class="text-white"><i class="fab fa-twitter fa-lg">Stroy_Yuhu</i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>