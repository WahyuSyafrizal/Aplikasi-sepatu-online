<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Order Success - YuhuShoes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --success-color: #2ECC71;
            --hover-color: #27AE60;
            --background-color: #F8F9FA;
        }

        body {
            background-color: var(--background-color);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .success-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .success-icon {
            width: 100px;
            height: 100px;
            background: var(--success-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            animation: scaleIn 0.5s ease-out 0.5s both;
        }

        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }

        .success-icon i {
            color: white;
            font-size: 50px;
        }

        .success-title {
            color: var(--success-color);
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 15px;
            opacity: 0;
            animation: fadeIn 0.5s ease-out 0.7s forwards;
        }

        .success-message {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 30px;
            opacity: 0;
            animation: fadeIn 0.5s ease-out 0.9s forwards;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .btn-shop {
            background: var(--success-color);
            color: white;
            padding: 15px 40px;
            border-radius: 50px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
            border: none;
            font-size: 1.1rem;
            opacity: 0;
            animation: fadeIn 0.5s ease-out 1.1s forwards;
        }

        .btn-shop:hover {
            background: var(--hover-color);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(46, 204, 113, 0.3);
            color: white;
        }

        .btn-shop i {
            margin-right: 10px;
        }

        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: var(--success-color);
            animation: confetti 5s ease-in-out infinite;
        }

        @keyframes confetti {
            0% {
                transform: translateY(0) rotateZ(0);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotateZ(360deg);
                opacity: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-card">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h1 class="success-title">Order Berhasil!</h1>
            <p class="success-message">
                Terima kasih telah berbelanja di YuhuShoes. Order Anda akan segera kami proses.
                Kami akan mengirimkan update status pesanan melalui email.
            </p>
            <a href="<?= base_url() ?>" class="btn btn-shop">
                <i class="fas fa-shopping-bag"></i>
                Lanjut Berbelanja
            </a>
        </div>
    </div>

    <script>
        function createConfetti() {
            const colors = ['#2ECC71', '#3498DB', '#9B59B6', '#F1C40F', '#E74C3C'];
            for(let i = 0; i < 50; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
                confetti.style.opacity = Math.random();
                confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                document.body.appendChild(confetti);
                
                setTimeout(() => {
                    confetti.remove();
                }, 5000);
            }
        }
        window.onload = createConfetti;
    </script>
</body>
</html>
