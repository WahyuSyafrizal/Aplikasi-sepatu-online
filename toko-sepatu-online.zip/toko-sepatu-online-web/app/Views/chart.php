<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Keranjang - YuhuShoes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #2C3E50;
            --accent-color: #E74C3C;
            --background-color: #F8F9FA;
            --hover-color: #34495E;
            --text-light: #6C757D;
        }

        body {
            background-color: var(--background-color);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar-cart {
            background: linear-gradient(135deg, var(--primary-color), var(--hover-color));
            color: white;
            padding: 1.5rem;
            border-radius: 0 0 1.5rem 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .navbar-cart h4 {
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .produk-item {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            overflow: hidden;
        }

        .produk-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
        }

        .produk-img {
            border-radius: 1rem;
            transition: transform 0.3s ease;
            max-width: 100%;
            height: auto;
        }

        .produk-img:hover {
            transform: scale(1.05);
        }

        .produk-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 0.75rem;
            font-size: 1.2rem;
        }

        .price-tag {
            display: inline-block;
            background: #E8F0FE;
            color: var(--primary-color);
            padding: 0.6rem 1.2rem;
            border-radius: 2rem;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }

        .quantity-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--primary-color);
            color: white;
            padding: 0.6rem 1.2rem;
            border-radius: 2rem;
            font-weight: 500;
            min-width: 100px;
        }

        .btn-hapus {
            color: var(--accent-color);
            border: 2px solid var(--accent-color);
            border-radius: 2rem;
            padding: 0.6rem 1.2rem;
            transition: all 0.3s ease;
            font-weight: 500;
            background: transparent;
        }

        .btn-hapus:hover {
            background: var(--accent-color);
            color: white;
            transform: translateY(-2px);
        }

        .btn-action {
            padding: 0.8rem 1.8rem;
            border-radius: 2rem;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-kembali {
            background: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }

        .btn-kembali:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }

        .btn-checkout {
            background: var(--primary-color);
            color: white;
            border: 2px solid var(--primary-color);
        }

        .btn-checkout:hover {
            background: var(--hover-color);
            border-color: var(--hover-color);
            transform: translateY(-2px);
        }

        .total-section {
            background: white;
            padding: 2rem;
            border-radius: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin: 2rem 0;
        }

        #total-harga {
            color: var(--primary-color);
            font-size: 1.8rem;
        }

        footer {
            background: linear-gradient(135deg, var(--primary-color), var(--hover-color));
            color: white;
            padding: 2.5rem 0;
            margin-top: auto;
            border-radius: 1.5rem 1.5rem 0 0;
        }

        .footer-content {
            opacity: 0.9;
        }

        .footer-content h4 {
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .cart-count {
            background: var(--accent-color) !important;
            padding: 0.4rem 0.8rem;
            border-radius: 1rem;
            margin-left: 0.5rem;
        }

        .deleted {
            animation: fadeOut 0.5s ease forwards;
        }
        
        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(-100%);
                height: 0;
                margin: 0;
                padding: 0;
            }
        }
        
        .price-update {
            animation: highlight 1s ease;
        }
        
        @keyframes highlight {
            0% { background-color: #E8F0FE; }
            50% { background-color: #FFD700; }
            100% { background-color: transparent; }
        }

        .cart-icon {
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-3px); }
        }

        .text-muted {
            color: var(--text-light) !important;
        }

        @media (max-width: 768px) {
            .produk-item {
                padding: 1rem !important;
            }
            
            .btn-action {
                width: 100%;
                justify-content: center;
                margin-bottom: 1rem;
            }

            .action-buttons .col-12 {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="navbar-cart">
            <div class="row align-items-center">
                <div class="col-6">
                    <h4 class="mb-0">YuhuShoes</h4>
                </div>
                <div class="col-6 text-end">
                    <a href="chart.html" class="btn btn-action btn-checkout">
                        <i class="fas fa-shopping-cart cart-icon me-2"></i>
                        Keranjang <span class="badge bg-warning cart-count">3</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="row g-4" id="product-container">
            <div class="col-12 product-item">
                <div class="produk-item p-4">
                    <div class="row align-items-center">
                        <div class="col-md-3">
                            <div class="position-relative">
                                <img src="images/sepatu.jpg" alt="Nike Air Max" class="produk-img img-fluid" />
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h5 class="produk-title">Nike Air Max</h5>
                            <span class="price-tag mb-2" data-price="950000">Rp 950.000</span>
                            <p class="text-muted mt-2">Social Inteligencia</p>
                        </div>
                        <div class="col-md-3">
                            <span class="quantity-badge">
                                <i class="fas fa-times me-1"></i>1
                            </span>
                        </div>
                        <div class="col-md-2 text-end">
                            <button class="btn btn-hapus" onclick="hapusItem(this)">
                                <i class="fas fa-trash-alt me-1"></i> Hapus
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 product-item">
                <div class="produk-item p-4">
                    <div class="row align-items-center">
                        <div class="col-md-3">
                            <div class="position-relative">
                                <img src="<?= base_url() ?>images/sepatu1.jpg" alt="Adidas Ultraboost" class="produk-img img-fluid" />
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h5 class="produk-title">Adidas Ultraboost</h5>
                            <span class="price-tag mb-2" data-price="1000000">Rp 1.000.000</span>
                            <p class="text-muted mt-2">Social Inteligencia</p>
                        </div>
                        <div class="col-md-3">
                            <span class="quantity-badge">
                                <i class="fas fa-times me-1"></i>1
                            </span>
                        </div>
                        <div class="col-md-2 text-end">
                            <button class="btn btn-hapus" onclick="hapusItem(this)">
                                <i class="fas fa-trash-alt me-1"></i> Hapus
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 product-item">
                <div class="produk-item p-4">
                    <div class="row align-items-center">
                        <div class="col-md-3">
                            <div class="position-relative">
                                <img src="<?= base_url() ?>images/sepatu2.jpg" alt="Puma RS-X" class="produk-img img-fluid" />
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h5 class="produk-title">Puma RS-X</h5>
                            <span class="price-tag mb-2" data-price="1850000">Rp 1.850.000</span>
                            <p class="text-muted mt-2">Social Inteligencia</p>
                        </div>
                        <div class="col-md-3">
                            <span class="quantity-badge">
                                <i class="fas fa-times me-1"></i>1
                            </span>
                        </div>
                        <div class="col-md-2 text-end">
                            <button class="btn btn-hapus" onclick="hapusItem(this)">
                                <i class="fas fa-trash-alt me-1"></i> Hapus
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-end">
            <div class="col-md-6">
                <div class="total-section">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Total Belanja:</h4>
                        <h3 class="mb-0 fw-bold" id="total-harga"></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row action-buttons">
            <div class="col-12 d-flex justify-content-between">
                <a href="<?= base_url() ?>" class="btn btn-action btn-kembali">
                    <i class="fas fa-arrow-left me-2"></i>
                    Lanjut Belanja
                </a>
                <a href="<?= base_url('checkout') ?>" class="btn btn-action btn-checkout">
                    Checkout Sekarang
                    <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content text-center">
                <h4>Toko Sepatu Online Yuhu</h4>
                <p class="mb-0">Temukan Gaya Anda Bersama Kami</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Format number to currency
        function formatRupiah(angka) {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(angka).replace('IDR', 'Rp');
        }

        // Calculate total price
        function hitungTotal() {
            const items = document.querySelectorAll('.product-item:not(.deleted) .price-tag');
            let total = 0;
            
            items.forEach(item => {
                const harga = parseInt(item.getAttribute('data-price'));
                total += harga;
            });
            
            const totalElement = document.getElementById('total-harga');
            totalElement.classList.add('price-update');
            totalElement.textContent = formatRupiah(total);
            
            // Update cart count
            const cartCount = document.querySelector('.cart-count');
            cartCount.textContent = items.length;
            
            setTimeout(() => {
                totalElement.classList.remove('price-update');
            }, 500);
        }

        // Delete item
        function hapusItem(button) {
            const productItem = button.closest('.product-item');
            productItem.classList.add('deleted');
            
            setTimeout(() => {
                productItem.style.display = 'none';
                hitungTotal();
            }, 500);
        }

        // Initialize total on page load
        window.onload = hitungTotal;
    </script>
</body>
</html>