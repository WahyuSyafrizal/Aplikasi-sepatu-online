<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Review Order - YuhuShoes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2C3E50;
            --accent-color: #3498DB;
            --success-color: #2ECC71;
            --warning-color: #F1C40F;
            --background-color: #F8F9FA;
            --card-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
        }

        body {
            background-color: var(--background-color);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: var(--primary-color);
        }

        .order-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: var(--card-shadow);
            transition: transform 0.3s ease;
        }

        .order-section:hover {
            transform: translateY(-5px);
        }

        .section-title {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #E0E0E0;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 60px;
            height: 2px;
            background-color: var(--accent-color);
        }

        .item-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #E0E0E0;
        }

        .price {
            font-weight: 600;
            color: var(--accent-color);
            font-size: 1.2rem;
        }

        .address-info {
            background: #F8F9FA;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid var(--accent-color);
        }

        .payment-info {
            background: #F8F9FA;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid var(--success-color);
        }

        .payment-details {
            margin: 10px 0;
        }

        .btn-action {
            padding: 12px 25px;
            border-radius: 50px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-back {
            background-color: var(--warning-color);
            color: var(--primary-color);
            border: none;
        }

        .btn-back:hover {
            background-color: #DAB10D;
            transform: translateY(-2px);
        }

        .btn-submit {
            background-color: var(--success-color);
            color: white;
            border: none;
        }

        .btn-submit:hover {
            background-color: #27AE60;
            transform: translateY(-2px);
        }

        .action-buttons {
            margin-top: 30px;
            margin-bottom: 50px;
        }

        .bank-info {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 10px 0;
        }

        .bank-icon {
            font-size: 24px;
            color: var(--accent-color);
        }

        .account-info {
            font-size: 1.1rem;
        }

        @media (max-width: 768px) {
            .action-buttons .col-12 {
                flex-direction: column;
                gap: 15px;
            }

            .btn-action {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="order-section">
            <h2 class="section-title">Review Order</h2>
            <div class="item-details">
                <div>
                    <h5 class="mb-2">Adidas Ultraboost</h5>
                    <span class="text-muted">Quantity: 1</span>
                </div>
                <div class="price">Rp1.000.000</div>
            </div>
        </div>

        <div class="order-section">
            <h2 class="section-title">Alamat Pengiriman</h2>
            <div class="address-info">
                <i class="fas fa-map-marker-alt me-2"></i>
                <span>Jl.32 unit 1, kec.Rimbo bujang Kab.Tebo</span>
            </div>
        </div>

        <div class="order-section">
            <h2 class="section-title">Metode Pembayaran</h2>
            <div class="payment-info">
                <h5 class="mb-3">Transfer Bank</h5>
                <div class="bank-info">
                    <i class="fas fa-university bank-icon"></i>
                    <div class="account-info">
                        <div>BSI James Bond</div>
                        <div class="text-muted">Rek. 1122334455</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row action-buttons">
            <div class="col-12 d-flex justify-content-between">
                <a href="<?= base_url('chart') ?>" class="btn btn-action btn-back">
                    <i class="fas fa-arrow-left me-2"></i>
                    Kembali ke Keranjang
                </a>
                <form action="<?= base_url('submit')?>" method="POST">
                    <button type="submit" class="btn btn-action btn-submit">
                        <i class="fas fa-check me-2"></i>
                        Submit Order
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>