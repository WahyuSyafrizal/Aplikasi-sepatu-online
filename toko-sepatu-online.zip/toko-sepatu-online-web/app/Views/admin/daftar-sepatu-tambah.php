<?= $this->extend('admin/template') ?>

<?= $this->section('main') ?>

<h2 class="mb-5">Tambah Sepatu</h2>

<form action="<?= base_url('admin/daftar-sepatu/create') ?>" method="post" enctype="multipart/form-data">
    <div class="mb-3">
        <label for="nama" class="form-label">Nama Sepatu</label>
        <input type="text" class="form-control" id="nama" name="nama" required>
    </div>
    <div class="mb-3">
        <label for="merk" class="form-label">Merk</label>
        <input type="text" class="form-control" id="merk" name="merk" required>
    </div>
    <div class="mb-3">
        <label for="ukuran" class="form-label">Ukuran</label>
        <input type="number" class="form-control" id="ukuran" name="ukuran" required>
    </div>
    <div class="mb-3">
        <label for="warna" class="form-label">Warna</label>
        <input type="text" class="form-control" id="warna" name="warna" required>
    </div>
    <div class="mb-3">
        <label for="cover" class="form-label">Gambar Sepatu</label>
        <input type="file" class="form-control" id="cover" name="cover" required>
    </div>
    <div class="mb-3">
        <label for="stok" class="form-label">Stok</label>
        <input type="number" class="form-control" id="stok" name="stok" required>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" class="form-control" id="harga" name="harga" required>
        <div class="mb-3">
            <a href="<?= base_url('admin/daftar-sepatu') ?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
</form>

<?= $this->endSection() ?>