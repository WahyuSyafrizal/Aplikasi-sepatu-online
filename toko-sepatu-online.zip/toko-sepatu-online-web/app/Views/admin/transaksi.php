<?= $this->extend('admin/template'); ?>
<?= $this->section('main'); ?>

<div class="container-fluid">
   <div class="d-flex justify-content-between align-items-center mb-4">
       <h2 class="mb-0">Daftar Transaksi</h2>
       
       <div class="d-flex gap-2">
           <select class="form-select form-select-sm" style="width: auto;">
               <option value="">Semua Status</option>
               <option value="pending">Pending</option>
               <option value="success">Sukses</option>
               <option value="cancelled">Dibatalkan</option>
           </select>
       </div>
   </div>

   <div class="card shadow-sm">
       <div class="card-body">
           <div class="table-responsive">
               <table class="table table-hover">
                   <thead>
                       <tr>
                           <th scope="col" class="text-center" width="5%">#</th>
                           <th scope="col" width="20%">Nama Pelanggan</th>
                           <th scope="col" width="20%">Tanggal</th>
                           <th scope="col" width="15%">Total</th>
                           <th scope="col" width="15%">Status</th>
                           <th scope="col" width="25%" class="text-center">Aksi</th>
                       </tr>
                   </thead>
                   <tbody>
                       <tr class="align-middle">
                           <td class="text-center">1</td>
                           <td>
                               <div class="d-flex align-items-center">
                                   <div class="avatar-circle me-2">JS</div>
                                   <div>
                                       <div class="fw-medium">James Smith</div>
                                       <small class="text-muted">#TRX001</small>
                                   </div>
                               </div>
                           </td>
                           <td>
                               <div>9 Des 2024</div>
                               <small class="text-muted">09:35 WIB</small>
                           </td>
                           <td class="fw-medium">Rp250.000</td>
                           <td>
                               <span class="badge status-badge status-pending">
                                   <i class="fas fa-clock me-1"></i>
                                   Pending
                               </span>
                           </td>
                           <td>
                               <div class="d-flex justify-content-center gap-2">
                                   <button class="btn btn-sm btn-outline-primary" title="Detail">
                                       <i class="fas fa-eye"></i>
                                   </button>
                                   <div class="dropdown">
                                       <button class="btn btn-sm btn-outline-success dropdown-toggle" 
                                               type="button" 
                                               data-bs-toggle="dropdown">
                                           <i class="fas fa-edit me-1"></i>
                                           Status
                                       </button>
                                       <ul class="dropdown-menu">
                                           <li>
                                               <a class="dropdown-item" href="<?= base_url('admin/transaksi/ubah-status')?>">
                                                   <i class="fas fa-check-circle text-success me-2"></i>
                                                   Ubah
                                               </a>
                                           </li>
                                           <li>
                                               <a class="dropdown-item" href="#">
                                                   <i class="fas fa-times-circle text-danger me-2"></i>
                                                   Batalkan
                                               </a>
                                           </li>
                                       </ul>
                                   </div>
                                   <a href="<?= base_url('admin/transaksi/hapus')?>" 
                                      class="btn btn-sm btn-outline-danger" 
                                      onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi ini?')">
                                       <i class="fas fa-trash"></i>
                                   </a>
                               </div>
                           </td>
                       </tr>
                   </tbody>
               </table>
           </div>
       </div>
   </div>
</div>

<style>
   .avatar-circle {
       width: 35px;
       height: 35px;
       background-color: #e9ecef;
       border-radius: 50%;
       display: flex;
       align-items: center;
       justify-content: center;
       font-weight: 600;
       color: #495057;
   }

   .status-badge {
       padding: 8px 12px;
       border-radius: 6px;
       font-weight: 500;
       font-size: 0.85rem;
   }

   .status-pending {
       background-color: #fff3cd;
       color: #856404;
       border: 1px solid #ffeeba;
   }

   .table thead th {
       background-color: #f8f9fa;
       font-weight: 600;
       border-bottom: 2px solid #dee2e6;
   }

   .table td {
       border-bottom: 1px solid #dee2e6;
   }

   .btn-sm {
       padding: 0.25rem 0.5rem;
   }

   .dropdown-item {
       padding: 0.5rem 1rem;
   }

   .dropdown-item:hover {
       background-color: #f8f9fa;
   }
</style>

<?= $this->endSection();?>