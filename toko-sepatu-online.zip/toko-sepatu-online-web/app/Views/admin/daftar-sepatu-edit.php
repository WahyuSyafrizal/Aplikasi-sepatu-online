<?= $this->extend('admin/template') ?>

<?= $this->section('main') ?>

<h2 class="mb-5">Edit Sepatu</h2>

<form action="<?= base_url('admin/daftar-sepatu/change/'.$shoes['id']); ?>" method="post" enctype="multipart/form-data">


    <div class="mb-3">
        <label for="nama" class="form-label">Nama Sepatu</label>
        <input type="text" class="form-control w-50" id="nama"
            placeholder="nama" name="nama" value="<?= $shoes['nama']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="merk" class="form-label">Merk</label>
        <input type="text" class="form-control" id="merk" name="merk" value="<?= $shoes['merk']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="ukuran" class="form-label">Ukuran</label>
        <input type="number" class="form-control" id="ukuran" name="ukuran" value="<?= $shoes['ukuran']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="warna" class="form-label">Warna</label>
        <input type="text" class="form-control" id="warna" name="warna" value="<?= $shoes['warna']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="cover" class="form-label">Gambar Sepatu Baru Jika Mau</label>
        <input type="file" class="form-control" id="cover" name="cover" autocomplete="off">
        
    </div>
    <div class="mb-3">
        <label for="stok" class="form-label">Stok</label>
        <input type="number" class="form-control" id="stok" name="stok" value="<?= $shoes['stok']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="number" class="form-control" id="harga" name="harga" value="<?= $shoes['harga']; ?>"
            autocomplete="off" required>
    </div>
    <div class="mb-3">
        <a href="<?= base_url('admin/daftar-sepatu') ?>" class="btn btn-secondary">Kembali</a>
        <button type="submit" class="btn btn-primary">Ubah</button>
    </div>
</form>

<?= $this->endSection() ?>