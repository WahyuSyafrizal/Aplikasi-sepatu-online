<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Sepatu</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css"> 
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus Sepatu</h1>

        <?php if (isset($sepatu)): ?>
            <p>Apakah Anda yakin ingin menghapus sepatu dengan data berikut?</p>
            <ul>
                <li><strong>Nama:</strong> <?= htmlspecialchars($sepatu['nama']); ?></li>
                <li><strong>Harga:</strong> Rp <?= number_format($sepatu['harga'], 2, ',', '.'); ?></li>
                <li><strong>Stok:</strong> <?= htmlspecialchars($sepatu['stok']); ?></li>
            </ul>

            <form action="/admin/daftar-sepatu/hapus/<?= $sepatu['id']; ?>" method="post">
                <?= csrf_field(); ?> 
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-sepatu" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <p>Data sepatu tidak ditemukan.</p>
            <a href="/admin/daftar-sepatu" class="btn btn-secondary">Kembali ke Daftar Sepatu</a>
        <?php endif; ?>
    </div>
</body>
</html>
