<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<div class="container-fluid">
    <h2 class="mb-4 text-2xl font-bold text-gray-800">Dashboard</h2>

    <div class="row mb-5">
        <div class="col-md-8">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body p-4 bg-gradient-to-r from-green-50 to-green-100 rounded">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="text-gray-600 mb-2">Total Pendapatan</h5>
                            <h3 class="display-6 fw-bold text-gray-800">Rp130.000.000</h3>
                            <p class="text-success mt-2 mb-0">
                                <i class="fas fa-arrow-up me-1"></i>
                                <span>12% dari bulan lalu</span>
                            </p>
                        </div>
                        <div class="bg-success p-3 rounded-circle text-white">
                            <i class="fas fa-chart-bar fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="text-gray-600 mb-2">Total Transaksi</h5>
                            <h3 class="display-6 fw-bold text-gray-800">145</h3>
                            <p class="text-primary mt-2 mb-0">
                                <i class="fas fa-arrow-up me-1"></i>
                                <span>8% dari bulan lalu</span>
                            </p>
                        </div>
                        <div class="bg-primary p-3 rounded-circle text-white">
                            <i class="fas fa-shopping-cart fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection();?>