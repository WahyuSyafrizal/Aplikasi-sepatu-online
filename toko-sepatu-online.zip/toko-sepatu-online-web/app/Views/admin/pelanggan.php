<?= $this->extend('admin/template'); ?>
<?= $this->section('main'); ?>

<div class="container-fluid">
   <div class="d-flex justify-content-between align-items-center mb-4">
       <h2 class="mb-0">Daftar Pelanggan</h2>

       <div class="d-flex gap-3">
           <div class="search-box">
               <input type="search" class="form-control" placeholder="Cari pelanggan...">
           </div>
       </div>
   </div>

   <div class="card shadow-sm">
       <div class="card-body">
           <div class="table-responsive">
               <table class="table table-hover">
                   <thead>
                       <tr>
                           <th scope="col" width="5%">no</th>
                           <th scope="col" width="20%">Nama</th>
                           <th scope="col" width="15%">No HP</th>
                           <th scope="col" width="35%">Alamat</th>
                           <th scope="col" width="15%">Total Transaksi</th>
                           <th scope="col" width="10%">Aksi</th>
                       </tr>
                   </thead>
                   <tbody>
                       <tr class="align-middle">
                           <td>1</td>
                           <td>
                               <div class="d-flex align-items-center">
                                   <div class="avatar-circle me-2">JS</div>
                                   <div>
                                       <div class="fw-medium">James Smith</div>
                                       <small class="text-muted">Member sejak Des 2023</small>
                                   </div>
                               </div>
                           </td>
                           <td>
                               <i class="fas fa-phone-alt text-muted me-1"></i>
                               085263714499
                           </td>
                           <td>
                               <i class="fas fa-map-marker-alt text-muted me-1"></i>
                               Jl. Km 16, Simp Sungai Duren, Muaro Jambi
                           </td>
                           <td>
                               <span class="badge bg-success">8 Transaksi</span>
                           </td>
                           <td>
                               <div class="dropdown">
                                   <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                       <i class="fas fa-ellipsis-v"></i>
                                   </button>
                                   <ul class="dropdown-menu">
                                       <li>
                                           <a class="dropdown-item" href="#">
                                               <i class="fas fa-eye text-primary me-2"></i>
                                               Lihat Detail
                                           </a>
                                       </li>
                                       <li>
                                           <a class="dropdown-item" href="#">
                                               <i class="fas fa-history text-info me-2"></i>
                                               Riwayat Transaksi
                                           </a>
                                       </li>
                                       <li><hr class="dropdown-divider"></li>
                                       <li>
                                           <a class="dropdown-item text-danger" 
                                              href="<?= base_url('admin/pelanggan/hapus')?>"
                                              onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini?')">
                                               <i class="fas fa-trash me-2"></i>
                                               Hapus
                                           </a>
                                       </li>
                                   </ul>
                               </div>
                           </td>
                       </tr>

                       <tr class="align-middle">
                           <td>2</td>
                           <td>
                               <div class="d-flex align-items-center">
                                   <div class="avatar-circle me-2 bg-info-subtle">ML</div>
                                   <div>
                                       <div class="fw-medium">Maria Lopez</div>
                                       <small class="text-muted">Member sejak Jan 2024</small>
                                   </div>
                               </div>
                           </td>
                           <td>
                               <i class="fas fa-phone-alt text-muted me-1"></i>
                               085277889900
                           </td>
                           <td>
                               <i class="fas fa-map-marker-alt text-muted me-1"></i>
                               Jl. Syukur, Telanaipura, Jambi
                           </td>
                           <td>
                               <span class="badge bg-success">5 Transaksi</span>
                           </td>
                           <td>
                               <div class="dropdown">
                                   <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                       <i class="fas fa-ellipsis-v"></i>
                                   </button>
                                   <ul class="dropdown-menu">
                                       <li><a class="dropdown-item" href="#"><i class="fas fa-eye text-primary me-2"></i>Lihat Detail</a></li>
                                       <li><a class="dropdown-item" href="#"><i class="fas fa-history text-info me-2"></i>Riwayat Transaksi</a></li>
                                       <li><hr class="dropdown-divider"></li>
                                       <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash me-2"></i>Hapus</a></li>
                                   </ul>
                               </div>
                           </td>
                       </tr>

                       <tr class="align-middle">
                           <td>3</td>
                           <td>
                               <div class="d-flex align-items-center">
                                   <div class="avatar-circle me-2 bg-warning-subtle">RK</div>
                                   <div>
                                       <div class="fw-medium">Rudi Kurniawan</div>
                                       <small class="text-muted">Member sejak Feb 2024</small>
                                   </div>
                               </div>
                           </td>
                           <td>
                               <i class="fas fa-phone-alt text-muted me-1"></i>
                               081366998877
                           </td>
                           <td>
                               <i class="fas fa-map-marker-alt text-muted me-1"></i>
                               Jl. Pattimura, Jelutung, Jambi
                           </td>
                           <td>
                               <span class="badge bg-success">3 Transaksi</span>
                           </td>
                           <td>
                               <div class="dropdown">
                                   <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                       <i class="fas fa-ellipsis-v"></i>
                                   </button>
                                   <ul class="dropdown-menu">
                                       <li><a class="dropdown-item" href="#"><i class="fas fa-eye text-primary me-2"></i>Lihat Detail</a></li>
                                       <li><a class="dropdown-item" href="#"><i class="fas fa-history text-info me-2"></i>Riwayat Transaksi</a></li>
                                       <li><hr class="dropdown-divider"></li>
                                       <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash me-2"></i>Hapus</a></li>
                                   </ul>
                               </div>
                           </td>
                       </tr>
                   </tbody>
               </table>
           </div>
       </div>
   </div>
</div>

<style>
   .avatar-circle {
       width: 40px;
       height: 40px;
       background-color: #e9ecef;
       border-radius: 50%;
       display: flex;
       align-items: center;
       justify-content: center;
       font-weight: 600;
       color: #495057;
   }

   .search-box {
       width: 300px;
   }

   .search-box .form-control {
       border-radius: 20px;
       padding-left: 1rem;
       padding-right: 1rem;
   }

   .table thead th {
       background-color: #f8f9fa;
       font-weight: 600;
       border-bottom: 2px solid #dee2e6;
   }

   .badge {
       padding: 0.5em 0.8em;
       font-weight: 500;
   }

   .dropdown-menu {
       padding: 0.5rem 0;
       box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
   }

   .dropdown-item {
       padding: 0.5rem 1rem;
   }

   .dropdown-item:hover {
       background-color: #f8f9fa;
   }
</style>

<?= $this->endSection();?>