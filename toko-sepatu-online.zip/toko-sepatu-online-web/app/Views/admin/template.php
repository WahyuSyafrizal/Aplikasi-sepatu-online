<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Toko Sepatu Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background: #2c3e50;
            min-height: 100vh;
            padding: 20px;
            color: white;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            color: #ecf0f1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .sidebar ul li a:hover {
            background: #34495e;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        .main-header {
            background: white;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .navbar-buttons .btn {
            margin-left: 10px;
        }

        footer {
            background: #2c3e50;
            color: white;
            padding: 20px 0;
            margin-top: 30px;
        }

        .content-area {
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 20px;
        }

        .btn-custom {
            background: #3498db;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .btn-custom:hover {
            background: #2980b9;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-3 sidebar">
                <h3 class="mb-4 text-center">Admin Panel</h3>
                <ul>
                    <li>
                        <a href="<?= base_url('admin/dashboard')?>">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('admin/daftar-sepatu')?>">
                            <i class="fas fa-shoe-prints"></i>
                            Daftar Sepatu
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('admin/transaksi')?>">
                            <i class="fas fa-shopping-cart"></i>
                            Transaksi
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('admin/pelanggan')?>">
                            <i class="fas fa-users"></i>
                            Pelanggan
                        </a>
                    </li>
                </ul>
            </div>

            <div class="col-9">
                <div class="main-header d-flex justify-content-between align-items-center">
                    <h4>Selamat Datang, Admin</h4>
                    <div class="navbar-buttons">
                        <a href="<?= base_url('index.php')?>" class="btn btn-custom">
                            <i class="fas fa-home"></i> Home
                        </a>
                        <a href="<?= base_url('logout')?>" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <div class="content-area">
                    <?= $this->renderSection('main'); ?>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content text-center">
                <h4>Toko Sepatu Online Yuhu</h4>
                <p class="mb-0">Temukan Gaya Anda Bersama Kami</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>