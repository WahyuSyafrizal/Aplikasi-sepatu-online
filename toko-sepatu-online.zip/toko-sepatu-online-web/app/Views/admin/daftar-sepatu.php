<?= $this->extend('admin/template'); ?>
<?= $this->section('main'); ?>

<div class="container-fluid">
   <div class="d-flex justify-content-between align-items-center mb-4">
       <h2 class="mb-0">Daftar Sepatu</h2>
       <a href="<?= base_url('admin/daftar-sepatu/tambah')?>" class="btn btn-primary">
           <i class="fas fa-plus-circle me-2"></i>Tambah Sepatu
       </a>
   </div>

   <div class="card shadow-sm">
       <div class="card-body">
           <div class="table-responsive">
               <table class="table table-hover">
                   <thead class="bg-light">
                       <tr>
                           <th scope="col" class="text-center">No</th>
                           <th scope="col">Nama Sepatu</th>
                           <th scope="col">Merek</th>
                           <th scope="col">Ukuran</th>
                           <th scope="col">Warna</th>
                           <th scope="col" class="text-center">Gambar</th>
                           <th scope="col" class="text-center">Stok</th>
                           <th scope="col" class="text-end">Harga</th>
                           <th scope="col" class="text-center">Aksi</th>
                       </tr>
                   </thead>
                   <tbody>
                       <?php foreach ($shoes as $sepatu): ?>
                       <tr class="align-middle">
                           <th scope="row" class="text-center"><?= $sepatu['id'] ?></th>
                           <td class="fw-medium"><?= $sepatu['nama'] ?></td>
                           <td><?= $sepatu['merk'] ?></td>
                           <td><?= $sepatu['ukuran'] ?></td>
                           <td><?= $sepatu['warna'] ?></td>
                           <td class="text-center">
                               <img src="<?= base_url($sepatu['cover'])?>" 
                                    alt="<?= $sepatu['nama'] ?>" 
                                    class="img-thumbnail"
                                    style="width: 100px; height: 100px; object-fit: cover;">
                           </td>
                           <td class="text-center">
                               <span class="badge <?= $sepatu['stok'] > 10 ? 'bg-success' : 'bg-warning' ?>">
                                   <?= $sepatu['stok'] ?>
                               </span>
                           </td>
                           <td class="text-end">
                               Rp<?= number_format($sepatu['harga'], 0, ',', '.') ?>
                           </td>
                           <td class="text-center">
                               <div class="btn-group" role="group">
                                   <a href="<?= base_url('admin/daftar-sepatu/edit') ?>/<?= $sepatu['id'] ?>" 
                                      class="btn btn-sm btn-outline-success" 
                                      title="Edit">
                                       <i class="fas fa-edit"></i>
                                   </a>
                                   <a href="<?= base_url('admin/daftar-sepatu/hapus') ?>/<?= $sepatu['id'] ?>" 
                                      class="btn btn-sm btn-outline-danger" 
                                      title="Hapus"
                                      onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                       <i class="fas fa-trash"></i>
                                   </a>
                               </div>
                           </td>
                       </tr>
                       <?php endforeach ?>
                   </tbody>
               </table>
           </div>
       </div>
   </div>
</div>

<style>
   .table th {
       font-weight: 600;
       background-color: #f8f9fa;
   }
   
   .table td {
       vertical-align: middle;
   }
   
   .img-thumbnail {
       border-radius: 8px;
       box-shadow: 0 2px 4px rgba(0,0,0,0.1);
   }
   
   .badge {
       font-size: 0.9em;
       padding: 6px 12px;
       border-radius: 6px;
   }
   
   .btn-group .btn {
       padding: 0.375rem 0.75rem;
   }
   
   .btn-group .btn i {
       font-size: 0.9em;
   }
</style>

<?= $this->endSection(); ?>