<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>YuhuShoes - Online Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #2C3E50;
            --accent-color: #3498DB;
            --background-color: #F8F9FA;
            --text-color: #2C3E50;
            --footer-bg: #2C3E50;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar-custom {
            background: linear-gradient(135deg, var(--primary-color), #34495E);
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .navbar-brand i {
            font-size: 2rem;
        }

        .cart-button {
            background-color: white;
            color: var(--primary-color);
            border-radius: 50px;
            padding: 0.8rem 1.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .cart-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            background-color: var(--accent-color);
            color: white;
        }

        .cart-icon {
            font-size: 1.2rem;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-3px); }
        }

        .cart-badge {
            background-color: #E74C3C !important;
            color: white;
            font-weight: 600;
            padding: 0.4rem 0.8rem;
            border-radius: 50px;
            margin-left: 5px;
        }

        .main-content {
            flex: 1;
            padding: 2rem 0;
        }

        footer {
            background: linear-gradient(135deg, var(--footer-bg), #34495E);
            color: white;
            padding: 3rem 0;
            margin-top: auto;
        }

        .footer-content {
            padding: 2rem;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.1);
        }

        .footer-content h4 {
            font-weight: 700;
            margin-bottom: 1rem;
            font-size: 1.8rem;
        }

        .footer-content p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .social-links {
            margin-top: 1.5rem;
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .social-link {
            color: white;
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .social-link:hover {
            color: var(--accent-color);
            transform: translateY(-3px);
        }

        @media (max-width: 768px) {
            .navbar-brand {
                font-size: 1.5rem;
            }
            
            .cart-button {
                padding: 0.6rem 1.2rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar-custom">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>" class="navbar-brand">
                    <i class="fas fa-shoe-prints"></i>
                    YuhuShoes
                </a>
                <a href="<?= base_url() ?>chart" class="cart-button">
                    <i class="fas fa-shopping-cart cart-icon"></i>
                    Keranjang
                    <span class="cart-badge">4</span>
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <?= $this->renderSection('main') ?>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content text-center">
                <h4>YuhuShoes</h4>
                <p class="mb-3">Temukan Gaya Anda Bersama Kami</p>
                <div class="social-links">
                    <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-link"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>